#Atividade 03 (Parte da AP1) — Semana 21/10 a 28/10 QXD0007 — Programação Orientada a Objetos — 2021.2 - UFC Quixadá

****

**Nome:** Lucas Levy de Oliveira Barros
**Matrícula:** 508160
**Data de Entrega:** 30/10/2021


**Obs:** Usei o Java 11