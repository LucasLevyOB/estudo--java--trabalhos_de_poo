#Atividade 04 (Parte da AP1) — Semana 29/10 a 05/11 QXD0007 — Programação Orientada a Objetos — 2021.2 - UFC Quixadá

****

**Nome:** Lucas Levy de Oliveira Barros
**Matrícula:** 508160
**Data de Entrega:** 04/11/2021


**Obs:** Usei o Java 11